var contextMenuItem = {
    "id":"spendMoney",
    "title":"Add to Highlight",
    "contexts":["selection"]
};

chrome.contextMenus.create(contextMenuItem)